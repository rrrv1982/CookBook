-------------------- DIM_TIME  ---------------------
DECLARE 
        START_DATE DATE := SYSDATE;
        END_DATE DATE := SYSDATE+10;        
        N_YEAR	Number(10);
        N_NUMBER_MONTH	Number(2);
        N_NUMBER_DAY_MONTH	Number(2);
        N_NUMBER_DAY_WEEK	Number(2);
        N_NUMBER_DAY_YEAR	Number(3);
        N_NUMBER_SEMESTER	Number(2);
        N_NUMBER_TRIMESTER	Number(2);
        N_NUMBER_WEEK_YEAR	Number(2);
        V2_NAME_SEMESTER	Varchar2(20);
        V2_NAME_TRIMESTER	Varchar2(20);
        V2_NAME_MONTH	Varchar2(20);
        V2_NAME_DAY	Varchar2(20);
        D_DATE	Date;
        V2_USER_CREATE	Varchar2(30);
        D_DATE_CREATE	Timestamp;
        V2_USER_UPDATE	Varchar2(30);
        D_DATE_UPDATE	Timestamp;
BEGIN   

    WHILE START_DATE <= END_DATE LOOP
        SELECT EXTRACT(YEAR FROM START_DATE) 	        INTO N_YEAR				FROM DUAL;
        SELECT EXTRACT(MONTH FROM START_DATE) 	        INTO N_NUMBER_MONTH		FROM DUAL;
        SELECT EXTRACT(DAY FROM START_DATE) 	        INTO N_NUMBER_DAY_MONTH	FROM DUAL;
        SELECT TO_CHAR(START_DATE,'D')			        INTO N_NUMBER_DAY_WEEK	FROM DUAL;
        SELECT TO_CHAR(START_DATE, 'DDD') 		        INTO N_NUMBER_DAY_YEAR	FROM DUAL;
        SELECT ROUND(TO_CHAR(START_DATE, 'Q')/2)        INTO N_NUMBER_SEMESTER	FROM DUAL;
        SELECT TO_CHAR(START_DATE,'Q') 			        INTO N_NUMBER_TRIMESTER	FROM DUAL;
        SELECT TO_CHAR(START_DATE,'WW')   		        INTO N_NUMBER_WEEK_YEAR	FROM DUAL;
        SELECT 'S'||ROUND(TO_CHAR(START_DATE, 'Q')/2)   INTO V2_NAME_SEMESTER	FROM DUAL;
        SELECT 'Q'||TO_CHAR(START_DATE,'Q')		        INTO V2_NAME_TRIMESTER	FROM DUAL;
        SELECT TO_CHAR(START_DATE,'fmMonth')  	        INTO V2_NAME_MONTH		FROM DUAL;
        SELECT TO_CHAR(START_DATE,'fmDay') 		        INTO V2_NAME_DAY		FROM DUAL;
        SELECT TO_DATE(START_DATE,'DD/MM/YYYY')         INTO D_DATE				FROM DUAL;
        SELECT USER                                     INTO V2_USER_CREATE     FROM DUAL;
        SELECT SYSDATE                                  INTO D_DATE_CREATE		FROM DUAL;
        SELECT USER                                     INTO V2_USER_UPDATE		FROM DUAL;
        SELECT SYSDATE                                  INTO D_DATE_UPDATE		FROM DUAL;
        
        DBMS_OUTPUT.PUT_LINE(N_YEAR);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_MONTH		);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_DAY_MONTH	);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_DAY_WEEK	);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_DAY_YEAR	);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_SEMESTER	);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_TRIMESTER	);
        DBMS_OUTPUT.PUT_LINE(N_NUMBER_WEEK_YEAR	);
        DBMS_OUTPUT.PUT_LINE(V2_NAME_SEMESTER	);
        DBMS_OUTPUT.PUT_LINE(V2_NAME_TRIMESTER	);
        DBMS_OUTPUT.PUT_LINE(V2_NAME_MONTH		);
        DBMS_OUTPUT.PUT_LINE(V2_NAME_DAY		);
        DBMS_OUTPUT.PUT_LINE(D_DATE				);
        DBMS_OUTPUT.PUT_LINE(V2_USER_CREATE		);
        DBMS_OUTPUT.PUT_LINE(D_DATE_CREATE		);
        DBMS_OUTPUT.PUT_LINE(V2_USER_UPDATE		);
        DBMS_OUTPUT.PUT_LINE(D_DATE_UPDATE		);            
        DBMS_OUTPUT.PUT_LINE('----------------------------');
        INSERT INTO DIM_TIME (
                                SK_N_TIME			,
                                N_YEAR				,
                                N_NUMBER_MONTH		,
                                N_NUMBER_DAY_MONTH	,
                                N_NUMBER_DAY_WEEK	,
                                N_NUMBER_DAY_YEAR	,
                                N_NUMBER_SEMESTER	,
                                N_NUMBER_TRIMESTER	,
                                N_NUMBER_WEEK_YEAR	,
                                V2_NAME_SEMESTER	,
                                V2_NAME_TRIMESTER	,
                                V2_NAME_MONTH		,
                                V2_NAME_DAY			,
                                D_DATE				,
                                V2_USER_CREATE		,
                                D_DATE_CREATE		,
                                V2_USER_UPDATE		,
                                D_DATE_UPDATE)
	VALUES (
		DIM_TIME_SK_N_TIME_SEQ.NEXT_VAL,
		N_YEAR				,
        N_NUMBER_MONTH		,
        N_NUMBER_DAY_MONTH	,
        N_NUMBER_DAY_WEEK	,
        N_NUMBER_DAY_YEAR	,
        N_NUMBER_SEMESTER	,
        N_NUMBER_TRIMESTER	,
        N_NUMBER_WEEK_YEAR	,
        V2_NAME_SEMESTER	,
        V2_NAME_TRIMESTER	,
        V2_NAME_MONTH		,
        V2_NAME_DAY			,
        D_DATE				,
        V2_USER_CREATE     	,
        D_DATE_CREATE		,
        V2_USER_UPDATE		,
        D_DATE_UPDATE);
    
        START_DATE := START_DATE + 1;
        
    END LOOP;

END;
