------------------------ SECUENCIAS ----------------------------- 

---------------------- SECUENCIA ID STORE -----------------------
CREATE SEQUENCE DIM_STORE_SK_N_STORE_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 999
                MINVALUE 1
				NOCACHE
				NOCYCLE;

---------------------- SECUENCIA ID FILM -----------------------				
CREATE SEQUENCE DIM_FILM_SK_N_FILM_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 99999
                MINVALUE 1
				NOCACHE
				NOCYCLE;

---------------------- SECUENCIA ID CUSTOMER -----------------------				
CREATE SEQUENCE DIM_CUSTOMER_SK_N_CUSTOMER_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 9999
                MINVALUE 1
				NOCACHE
				NOCYCLE;
---------------------- SECUENCIA ID LOCATION -----------------------			
CREATE SEQUENCE DIM_LOCATION_SK_N_LOCATION_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 99999
                MINVALUE 1
				NOCACHE
				NOCYCLE;

---------------------- SECUENCIA ID EMPLOYEE -----------------------			
CREATE SEQUENCE DIM_EMPLOYEE_SK_N_EMPLOYEE_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 9999
                MINVALUE 1
				NOCACHE
				NOCYCLE;
			
---------------------- SECUENCIA ID TIME -----------------------
CREATE SEQUENCE DIM_TIME_SK_N_TIME_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 999999
                MINVALUE 1
				NOCACHE
				NOCYCLE;

---------------------- SECUENCIA ID RENT -----------------------
CREATE SEQUENCE FACT_RENT_SK_N_RENT_SEQ
				INCREMENT BY 1
				START WITH 1
				MAXVALUE 999999
                MINVALUE 1
				NOCACHE
				NOCYCLE;