------------------------ TABLAS ----------------------
------------------- DIMENSIÓN STORE ------------

CREATE TABLE DIM_STORE (
    SK_N_STORE	Number(10),
    NK_N_STORE_ID	Number(10),
    V2_NAME_STORE	Varchar2(30),
    V2_ADRESS_STORE	Varchar2(30),
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	timestamp
) TABLESPACE TS_SOLUTION;

------------------- DIMENSIÓN FILM ------------

CREATE TABLE DIM_FILM (
    SK_N_FILM	Number(10),
    NK_N_FILM_ID	Number(10),
    V2_TITLE	Varchar2(255),
    V2_RELEASE_YEAR	Number (4),
    V2_GENDER	Varchar2(25),
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	Timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	Timestamp
) TABLESPACE TS_SOLUTION;

------------------- DIMENSIÓN CUSTOMER ------------

CREATE TABLE DIM_CUSTOMER (
    SK_N_CUSTOMER	Number(10),
    NK_N_CUSTOMER_ID	Number(10),
    V2_FIRST_NAME	Varchar2(30),
    V2_LAST_NAME	Varchar2(30),
    V2_EMAIL	Varchar2(30),
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	Timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	Timestamp
) TABLESPACE TS_SOLUTION;

------------------- DIMENSIÓN LOCATION ------------

CREATE TABLE DIM_LOCATION(
    SK_N_LOCATION	Number(10),
    NK_N_CITY_ID	Number(10),
    V2_NAME_CITY	Varchar2(30),
    V2_NAME_COUNTRY	Varchar2(30),
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	Timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	Timestamp
) TABLESPACE TS_SOLUTION;

------------------- DIMENSIÓN EMPLOYEE ------------

CREATE TABLE DIM_EMPLOYEE (
    SK_N_EMPLOYEE	Number(10),
    NK_N_STAFF_ID	Number(10),
    V2_USERNAME	Varchar2(16),
    V2_FIRST_NAME	Varchar2(45),
    V2_LAST_NAME	Varchar2(45),
    V2_EMAIL	Varchar2(50),
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	Timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	Timestamp
) TABLESPACE TS_SOLUTION;

------------------- DIMENSIÓN TIEMPO ------------

CREATE TABLE DIM_TIME 
(
    SK_N_TIME	Number(10),
    N_YEAR	Number(10),
    N_NUMBER_MONTH	Number(2),
    N_NUMBER_DAY_MONTH	Number(2),
    N_NUMBER_DAY_WEEK	Number(2),
    N_NUMBER_DAY_YEAR	Number(3),
    N_NUMBER_SEMESTER	Number(2),
    N_NUMBER_TRIMESTER	Number(2),
    N_NUMBER_WEEK_YEAR	Number(2),
    V2_NAME_SEMESTER	Varchar2(20),
    V2_NAME_TRIMESTER	Varchar2(20),
    V2_NAME_MONTH	Varchar2(20),
    V2_NAME_DAY	Varchar2(20),
    D_DATE	Date,
    V2_USER_CREATE	Varchar2(30),
    D_DATE_CREATE	Timestamp,
    V2_USER_UPDATE	Varchar2(30),
    D_DATE_UPDATE	Timestamp
) TABLESPACE TS_SOLUTION;

------------------- TABLA DE HECHOS RENT ------------

CREATE TABLE FACT_RENT(
    SK_N_RENT	Number(10),
    NK_N_RENTAL_ID	Number(10),
    N_VALUE_RENTAL	Number(38,2),
    FK_SK_D_DATE_RENT	Number(10),
    FK_SK_D_DATE_RETURN	Number(10),
    N_DURARION_RENT	Number(10),
    FK_SK_N_FILM_ID	Number(10),
    FK_SK_N_STORE_ID	Number(10),
    FK_SK_N_STORECITY_ID	Number(10),
    FK_SK_N_CUSTOMER_ID	Number(10),
    FK_SK_N_CUSTOMERCITY_ID	Number(10),
    FK_SK_N_EMPLOYEE_ID	Number(10),
    FK_NK_N_STAFF_ID	Number(10),
    FK_NK_N_STORE_ID	Number(10),
    FK_NK_N_STORE_CITY_ID	Number(10),
    FK_NK_N_FILM_ID	Number(10),
    FK_NK_N_CUSTOMER_ID	Number(10),
    FK_NK_CUSTOMER_CITYID	Number(10),
	V2_USER_CREATE	Varchar2(30),
	D_DATE_CREATE	TimeStamp,
	V2_USER_UPDATE	Varchar2(30),
	D_DATE_UPDATE	TimeStamp

) TABLESPACE TS_SOLUTION;