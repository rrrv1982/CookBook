----------- EJECUTE ESTE SCRIPT ------
@Anexo3_Script_CreationTablespace.sql
@Anexo4_Script_CreationTables.sql
@Anexo5_Script_primary_key.sql
@Anexo6_Script_create_foreign_key.sql
@Anexo7_Script_create_sequences.sql
@Anexo8_Script_create_indexes.sql

